@extends('layouts.login')
@section('content')


    <h1>{{$desk}}</h1>
    <h5><?=XURL?></h5>


@endsection

