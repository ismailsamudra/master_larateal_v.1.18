<br><br><br><br><br>
<center><h1>WELCOME</h1></center><?php /**PATH D:\LARAVEL\LaraTeal_V.1.10\resources\views/costume/mzta40v9ar/index.blade.php ENDPATH**/ ?>