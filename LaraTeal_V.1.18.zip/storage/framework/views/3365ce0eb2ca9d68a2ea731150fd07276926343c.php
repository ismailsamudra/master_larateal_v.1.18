<br><br><br><br><br>
<center><h1>WELCOME</h1></center><?php /**PATH D:\LARAVEL\LaraTeal_V.1.10\resources\views/costume/mn8rjkchnd/index.blade.php ENDPATH**/ ?>