
<?php $__env->startSection('content'); ?>
<!-- TOP NAVIGASI START -->
<div class="btl">
    <a href="javascript:void(0);" onclick="add();" class="btn-sm bg-1 r20" title="ADD"><i class="fa fa-plus"></i></a>
    <a href="javascript:history.back();" class="btn-sm bg-1 r20" title="Back"><i class="fa fa-arrow-left fa-sm"></i></a>
</div>
<div class="btr">
    <a href="javascript:void(0);" onclick="$(`#dguser`).datagrid(`reload`);" class="btn-sm bt-1 r20" title="Reload"><i class="fa-solid fa-sync fa-sm"></i></a>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<div class="container mt-2">
    <center>
        <a href="" class="text-<?php echo e((inc('tema')=='dark')?'white':'dark'); ?>"><i class="<?php echo e($icon); ?> mr-2 mb-3"></i><strong><small><?php echo e($label); ?></small></strong></a>
    </center>



</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\LaraTeal_V.1.10\resources\views/costume/mlyge4xywh/index.blade.php ENDPATH**/ ?>